# -*- coding: utf-8 -*-

from ex4.src import ex4

def main():
    """
    Machine Learning Class - Exercise 4 Neural Network Learning
    """
    ex4()

if __name__ == '__main__':
    main()